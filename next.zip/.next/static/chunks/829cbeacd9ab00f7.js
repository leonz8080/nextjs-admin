__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/22db1a909951403b.js",
  "static/chunks/turbopack-29317232ec316666.js"
])
