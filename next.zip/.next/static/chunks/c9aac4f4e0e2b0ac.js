__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/22db1a909951403b.js",
  "static/chunks/turbopack-05b44278316fb6f4.js"
])
