var R=require("../../chunks/[turbopack]_runtime.js")("server/app/api/route.js")
R.c("server/chunks/[root-of-the-server]__d46e5868._.js")
R.c("server/chunks/_5e2e59be._.js")
R.c("server/chunks/[root-of-the-server]__3f931a7f._.js")
R.c("server/chunks/node_modules_next_dist_e4af4b05._.js")
R.c("server/chunks/[root-of-the-server]__967d1036._.js")
R.m(39428)
R.m(65366)
module.exports=R.m(65366).exports
