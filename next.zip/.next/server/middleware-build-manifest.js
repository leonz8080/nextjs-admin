globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/22db1a909951403b.js",
      "static/chunks/turbopack-29317232ec316666.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/22db1a909951403b.js",
      "static/chunks/turbopack-05b44278316fb6f4.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/d11f6a434d45d738.js",
    "static/chunks/e6b0468bc5e7fb2f.js",
    "static/chunks/db8f8797ab57ee2a.js",
    "static/chunks/2008ffcf9e5b170c.js",
    "static/chunks/turbopack-e09e197392845d7c.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];