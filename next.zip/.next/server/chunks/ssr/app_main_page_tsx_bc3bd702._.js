module.exports=[62861,a=>{"use strict";a.s(["default",()=>c]);var b=a.i(87924);function c(){return(0,b.jsx)(b.Fragment,{})}}];

//# sourceMappingURL=app_main_page_tsx_bc3bd702._.js.map